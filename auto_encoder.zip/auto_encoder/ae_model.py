import torch


class AutoEncoder(torch.nn.Module):
    def __init__(self):
        super(AutoEncoder, self).__init__()
        self.encoder = torch.nn.Sequential(
            torch.nn.Linear(28 * 28, 1000),
            torch.nn.ReLU(True),
            torch.nn.Linear(1000, 1000),
            torch.nn.ReLU(True),
            torch.nn.Linear(1000, 750),
            torch.nn.ReLU(True),
            torch.nn.Linear(750, 500),
            torch.nn.ReLU(True),
            torch.nn.Linear(500, 250),
            torch.nn.ReLU(True),
            torch.nn.Linear(250, 30),
            # torch.nn.ReLU(True),
            # torch.nn.Linear(30, 3)
            )

        self.decoder = torch.nn.Sequential(
            # torch.nn.Linear(3, 30),
            # torch.nn.ReLU(True),
            torch.nn.Linear(30, 250),
            torch.nn.ReLU(True),
            torch.nn.Linear(250, 500),
            torch.nn.ReLU(True),
            torch.nn.Linear(500, 750),
            torch.nn.ReLU(True),
            torch.nn.Linear(750, 1000),
            torch.nn.ReLU(True),
            torch.nn.Linear(1000, 1000),
            torch.nn.ReLU(True),
            torch.nn.Linear(1000, 28 * 28),
            torch.nn.Tanh())

    def forward(self, x):
        encoded_data = self.encoder(x)
        decoded_data = self.decoder(encoded_data)
        return encoded_data, decoded_data



