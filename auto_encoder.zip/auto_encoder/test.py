from simple.auto_encoder.ae_model import AutoEncoder
from gan_based.twod_dcgan.mnist.twod_my_data_loader import MyDataLoader
import Helper
import numpy
import torch.utils.data
import torchvision
from matplotlib import cm
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
import os

batch_size = 128
device = torch.device('cpu')
print(">> Device Info: {} is in use".format(device))

model = AutoEncoder().to(device)
model.load_state_dict(torch.load('AE_MNIST/CheckPointStore/final_epoch_280'))
model.eval()
NORMAL_NUM = 0
dir_path = '../../../public_data/mem_ae_mnist/0'
img_transform = torchvision.transforms.Compose([
    torchvision.transforms.ToTensor(),
    torchvision.transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
])
valid_data_set = MyDataLoader(path=os.path.join(dir_path, "testing"),
                              transform=img_transform,
                              normal_number=NORMAL_NUM)

valid_data_loader = torch.utils.data.DataLoader(dataset=valid_data_set,
                                                batch_size=batch_size,
                                                num_workers=0,
                                                shuffle=True,
                                                drop_last=True)

criterion = torch.nn.MSELoss()

with torch.no_grad():
    normal_mse_loss = []
    abnormal_mse_loss = []
    row = None
    column = None
    for index, (images, label) in enumerate(valid_data_loader):
        current_images = images.view(images.size(0), -1).to(device)
        _, decoded_data = model(current_images)
        if row is not None:
            if column is None:
                column = row
            else:
                if index <= 9:
                    column = numpy.concatenate((column, row), axis=1)
        row = None
        counter = 0
        for visual_index in range(batch_size):

            if label[visual_index] == 0:
                normal_mse_loss.append(criterion(current_images[visual_index],
                                                 decoded_data[visual_index]).cpu().detach().numpy())

            if label[visual_index] != 0:
                counter += 1
                if counter < 8:
                    if row is None:
                        typical_image = current_images[visual_index].cpu().detach().numpy().reshape(28, 28)
                        row = decoded_data[visual_index].cpu().detach().numpy().reshape(28, 28)
                        row = numpy.concatenate((typical_image,
                                                 row), axis=0)
                    else:
                        typical_image = current_images[visual_index].cpu().detach().numpy().reshape(28, 28)
                        typical_image = numpy.concatenate((typical_image,
                                                           decoded_data[visual_index].
                                                           cpu().detach().numpy().reshape(28, 28)), axis=0)
                        row = numpy.concatenate((row, typical_image), axis=0)
                abnormal_mse_loss.append(criterion(current_images[visual_index],
                                                   decoded_data[visual_index]).cpu().detach().numpy())
    plt.imshow(column, cmap='gray')
    plt.axis("off")
    plt.show()
    normal_mse_loss = normal_mse_loss
    abnormal_mse_loss = abnormal_mse_loss
    Helper.plot_2d_chart(x1=numpy.arange(0, len(normal_mse_loss)), y1=normal_mse_loss, label1='normal_loss',
                         x2=numpy.arange(len(normal_mse_loss),
                                         len(normal_mse_loss) + len(abnormal_mse_loss)),
                         y2=abnormal_mse_loss, label2='abnormal_loss', title="")
    min_value = min(normal_mse_loss + abnormal_mse_loss)
    max_value = max(normal_mse_loss + abnormal_mse_loss)
    # normal_mse_loss = numpy.asarray(normal_mse_loss)
    # abnormal_mse_loss = numpy.asarray(abnormal_mse_loss)
    abnormal_mse_loss = abnormal_mse_loss
    normal_mse_loss = normal_mse_loss
    tp_list = []
    fp_list = []
    step = .01
    for threshold in numpy.arange(min_value - step, max_value + step, step):
        print("{}/{} => on process".format(str(threshold),
                                           str(max_value-min_value)))
        tp = 0
        tn = 0
        fp = 0
        fn = 0
        for obj in (normal_mse_loss + abnormal_mse_loss):
            if obj <= threshold and obj in normal_mse_loss:
                tp += 1
            elif obj <= threshold and obj in abnormal_mse_loss:
                fp += 1
            elif obj > threshold and obj in normal_mse_loss:
                fn += 1
            elif obj > threshold and obj in abnormal_mse_loss:
                tn += 1
            else:
                print("ERROR")
                exit(1)
        tp_list.append(tp / (tp + fn))
        fp_list.append(fp / (fp + tn))

    Helper.draw_roc(tp_list, fp_list, title="")

# test_data_set = torchvision.datasets.MNIST('../../../public_data/MNIST_data/', transform=img_transform)
# idx = test_data_set.train_labels != 0
# test_data_set.train_labels = test_data_set.train_labels[idx]
# test_data_set.train_data = test_data_set.train_data[idx]
#
# test_data_set_2 = torchvision.datasets.MNIST('../../../public_data/MNIST_data/', transform=img_transform)
# idx2 = test_data_set_2.train_labels == 0
# test_data_set_2.train_labels = test_data_set_2.train_labels[idx2]
# test_data_set_2.train_data = test_data_set_2.train_data[idx2]
#
# test_data_loader = torch.utils.data.DataLoader(test_data_set, batch_size=128, shuffle=True)
# test_data_loader_2 = torch.utils.data.DataLoader(test_data_set_2, batch_size=128, shuffle=True)
# # view_data = test_data_set.train_data[:1000].view(-1, 28 * 28).type(torch.FloatTensor) / 255.
# # encode, decode = model(view_data.to(device))
# # fig = plt.figure(2)
# # ax = Axes3D(fig)
# # X, Y, Z = encode.data[:, 0].cpu().detach().numpy(), \
# #           encode.data[:, 1].cpu().detach().numpy(), \
# #           encode.data[:, 2].cpu().detach().numpy()
# #
# # values = test_data_set.train_labels[:1000].numpy()
# # for x, y, z, s in zip(X, Y, Z, values):
# #     c = cm.rainbow(int(255 * s / 9))
# #     ax.text(x, y, z, s, backgroundcolor=c)
# # ax.set_xlim(X.min(), X.max())
# # ax.set_ylim(Y.min(), Y.max())
# # ax.set_zlim(Z.min(), Z.max())
# # plt.show()
# # Helper.mnist_plot_encoded_3d_chart(view_data, encode)
#
# ground_truth = test_data_set.train_data[:50].view(-1, 28 * 28).type(torch.FloatTensor) / 255.
# ground_truth_2 = test_data_set_2.train_data[:20].view(-1, 28 * 28).type(torch.FloatTensor) / 255.
# _, predict = model(ground_truth.to(device))
# _, predict_2 = model(ground_truth_2.to(device))
# ground_truth = ground_truth.numpy()
# predict = predict.detach().numpy()
# ground_truth_2 = ground_truth_2.numpy()
# predict_2 = predict_2.detach().numpy()
#
#
# result = []
# for i in range(ground_truth.shape[0]):
#     counter = 0
#     for j in range(ground_truth.shape[1]):
#         counter += numpy.square(ground_truth[i][j] - predict[i][j])
#     result.append(numpy.float(counter/ground_truth.shape[1]))
#
# for i in range(ground_truth_2.shape[0]):
#     counter = 0
#     for j in range(ground_truth_2.shape[1]):
#         counter += numpy.square(ground_truth_2[i][j] - predict_2[i][j])
#     result.append(numpy.float(counter/ground_truth_2.shape[1]))
#
# x = test_data_set.train_labels[:50].numpy()
# print(x, test_data_set_2.train_labels[:20].numpy())
# y1 = result
# print(y1)
# plt.plot(numpy.arange(0, 70), y1, color='red', label='book_covers', marker='o', mec='r', mfc='w')
# plt.xlabel('labels')
# plt.xticks(rotation=45)
# plt.ylabel('loss')
# plt.legend()
# plt.title('line_chart_for_searching')
# plt.grid()
# plt.show()
# # Helper.plot_2d_chart(x=numpy.array(0, 70), y=result)
