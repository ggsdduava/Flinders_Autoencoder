import os
import torch
import numpy
import torch.utils.data
import Helper
import torchvision
from Recorder import Recorder
from simple.auto_encoder.ae_model import AutoEncoder
from gan_based.twod_dcgan.mnist.twod_my_data_loader import MyDataLoader
import matplotlib.pyplot as plt

recorder = Recorder('simple_auto_encoder', 'AE_MNIST')
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
num_epochs = 360
batch_size = 128
learning_rate = 1e-3


def to_img(x):
    x = 0.5 * (x + 1)
    x = x.clamp(0, 1)
    x = x.view(x.size(0), 1, 28, 28)
    return x


dir_path = '../../../public_data/mem_ae_mnist/0'
img_transform = torchvision.transforms.Compose([
    torchvision.transforms.ToTensor(),
    torchvision.transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
])
NORMAL_NUM = 0
train_data_set = MyDataLoader(path=os.path.join(dir_path, "training"),
                              transform=img_transform,
                              normal_number=NORMAL_NUM,
                              shuffle=True)

valid_data_set = MyDataLoader(path=os.path.join(dir_path, "testing"),
                              transform=img_transform,
                              normal_number=NORMAL_NUM)


# data_loader = Helper.mnist_get_data_set(dir_path, get_number=0, train=True)
# valid_data_loader = Helper.mnist_get_data_set(dir_path, valid=True)
data_loader = torch.utils.data.DataLoader(dataset=train_data_set,
                                          batch_size=batch_size,
                                          num_workers=0,
                                          shuffle=True)

valid_data_loader = torch.utils.data.DataLoader(dataset=valid_data_set,
                                                batch_size=batch_size,
                                                num_workers=0,
                                                shuffle=True,
                                                drop_last=True)

model = AutoEncoder().to(device)
criterion = torch.nn.MSELoss()
optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate, weight_decay=1e-5)
lr_scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=10, gamma=0.9)

for epoch in range(num_epochs):
    model.train()
    lr_scheduler.step()
    for index, data in enumerate(data_loader):
        img, k = data
        # print(k)
        img = img.view(img.size(0), -1)
        img = torch.autograd.Variable(img).to(device)
        # ===================forward=====================
        e_output, d_output = model(img)
        loss = criterion(d_output, img)
        # ===================backward====================
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        # if index % 30 == 0:
        #     recorder.record(loss=loss, epoch=epoch, loss_name='',
        #                     num_batches=len(data_loader), n_batch=index)
        #     pic_out = to_img(d_output.cpu().data)[:10].cpu().detach().numpy().squeeze()
        #     pic_in = to_img(img.cpu().data)[:10].cpu().detach().numpy().squeeze()
        #
        #     pic_total = Helper.mnist_get_visualize_data(pic_in, pic_out)
    #            recorder.log_images(pic_total, 20, epoch, index, len(data_loader), title='training_set')

    # ===================log========================

    # print('epoch [{}/{}], loss:{:.4f}'
    #       .format(epoch + 1, num_epochs, loss.cpu().data.numpy()))
        Recorder.display_status(epoch, num_epochs=num_epochs, loss=loss, n_batch=index, num_batches=len(data_loader))
    if epoch % 20 == 0:
        model.eval()
        with torch.no_grad():
            normal_mse_loss = []
            abnormal_mse_loss = []
            row = None
            column = None
            for index, (images, label) in enumerate(valid_data_loader):
                current_images = images.view(images.size(0), -1).to(device)
                _, decoded_data = model(current_images)
                if row is not None:
                    if column is None:
                        column = row
                    else:
                        if index <= 16:
                            column = numpy.concatenate((column, row), axis=1)
                row = None
                for visual_index in range(batch_size):
                    if row is None:
                        row = decoded_data[visual_index].cpu().detach().numpy().reshape(28, 28)
                    else:
                        row = numpy.concatenate((row, decoded_data[visual_index].
                                                cpu().detach().numpy().reshape(28, 28)), axis=0)

                    if label[visual_index] != 0:
                        normal_mse_loss.append(criterion(current_images[visual_index],
                                                         decoded_data[visual_index]).cpu().detach().numpy())

                    if label[visual_index] == 0:
                        abnormal_mse_loss.append(criterion(current_images[visual_index],
                                                           decoded_data[visual_index]).cpu().detach().numpy())

        if epoch > 260 or epoch == 0:
            plt.imshow(column[:50], cmap='gray')
            plt.savefig('SAE_'+str(epoch)+'.png')
            plt.close()
            normal_mse_loss = normal_mse_loss[:50]
            abnormal_mse_loss = abnormal_mse_loss[:50]
            Helper.plot_2d_chart(x1=numpy.arange(0, len(normal_mse_loss)), y1=normal_mse_loss, label1='normal_loss',
                                 x2=numpy.arange(len(normal_mse_loss),
                                                 len(normal_mse_loss) + len(abnormal_mse_loss)),
                                 y2=abnormal_mse_loss, label2='abnormal_loss',
                                 save_path=os.path.join('PLOT_IMAGES_INSYMMETRIC', 'insymmetric' + '_' + str(epoch)))

    # if epoch % 2 == 0:
    #     model.eval()
    #     result_1 = []
    #     result_2 = []
    #     with torch.no_grad():
    #         for index, data in enumerate(valid_data_loader):
    #             valid_img, _ = data
    #             valid_image = valid_img.view(valid_img.size(0), -1).to(device)
    #             _, output_image = model(valid_image)
    #             pic_out = to_img(output_image.cpu().data)[:10].cpu().detach().numpy().squeeze()
    #             pic_in = to_img(valid_image.cpu().data)[:10].cpu().detach().numpy().squeeze()
    #             pic_total = Helper.mnist_get_visualize_data(pic_in, pic_out)
    #             recorder.log_images(pic_total, 20, epoch, index, len(data_loader), title='validation_set')
    #
    #             ground_truth = valid_image.cpu().detach().numpy()
    #             predict = output_image.cpu().detach().numpy()
    #             for i in range(ground_truth.shape[0]):
    #                 counter = 0
    #                 for j in range(ground_truth.shape[1]):
    #                     counter += numpy.square(ground_truth[i][j] - predict[i][j])
    #                 result_1.append(numpy.float(counter / ground_truth.shape[1]))
    #             print("valid: ", result_1)
    #             break
    #
    #         for index, data in enumerate(data_loader):
    #             img, k = data
    #             img = img.view(img.size(0), -1)
    #             img = torch.autograd.Variable(img).to(device)
    #             # ===================forward=====================
    #             e_output, d_output = model(img)
    #             ground_truth = img.cpu().detach().numpy()
    #             predict = d_output.cpu().detach().numpy()
    #             for i in range(ground_truth.shape[0]):
    #                 counter = 0
    #                 for j in range(ground_truth.shape[1]):
    #                     counter += numpy.square(ground_truth[i][j] - predict[i][j])
    #                 result_2.append(numpy.float(counter / ground_truth.shape[1]))
    #             print("train: ", result_2)
    #             break
    #         Helper.plot_abnormal_normal_chart(result_1, result_2, show=False)
    #
    if epoch % 20 == 0 and epoch > 260:
        recorder.save_models(model=model, epoch=epoch, name="final")
